class BankAccount {

    String accountHolderName;
    int accountNumber;
    String accountType;
    double accountBalance;

    // Parameterized Constructor
    BankAccount(String accountHolderName, int accountNumber,
                String accountType, double accountBalance) {

        this.accountHolderName = accountHolderName;
        this.accountNumber = accountNumber;
        this.accountType = accountType;
        this.accountBalance = accountBalance;
    }

    // Deposit method
    void deposit(double amount) {
        if (amount > 0) {
            accountBalance += amount;
            System.out.println("Deposited Amount : " + amount);
            System.out.println("New Balance      : " + accountBalance);
        } else {
            System.out.println("Invalid deposit amount");
        }
    }

    // Withdraw method
    void withdraw(double amount) {
        if (amount > 0 && amount <= accountBalance) {
            accountBalance -= amount;
            System.out.println("Withdrawn Amount  : " + amount);
            System.out.println("Remaining Balance : " + accountBalance);
        } else if (amount > accountBalance) {
            System.out.println("Insufficient Balance");
        } else {
            System.out.println("Invalid withdrawal amount");
        }
    }

    // Balance enquiry
    void balanceEnquiry() {
        System.out.println("\n--- Account Details ---");
        System.out.println("Account Holder : " + accountHolderName);
        System.out.println("Account Number : " + accountNumber);
        System.out.println("Account Type   : " + accountType);
        System.out.println("Balance        : " + accountBalance);
    }
}

public class Main {

    public static void main(String[] args) {

        BankAccount account = new BankAccount(
            "Ravi", 1001, "Savings", 10000
        );

        account.balanceEnquiry();

        System.out.println("\n--- Deposit Transaction ---");
        account.deposit(5000);

        System.out.println("\n--- Withdrawal Transaction ---");
        account.withdraw(3000);

        System.out.println("\n--- Final Balance ---");
        account.balanceEnquiry();

        System.out.println("\n--- Insufficient Balance Test ---");
        account.withdraw(15000);

        System.out.println("\n--- Invalid Deposit Test ---");
        account.deposit(-500);
    }
}